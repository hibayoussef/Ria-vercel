export { default } from 'app/fuse-layouts/FuseLayouts';
